import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Link, useLocation } from "react-router-dom";
import { Gamepad2, Users, MessageCircle, UserRound } from "lucide-react";
import { cn } from "../lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const shouldHideNav = location.pathname.startsWith("/chat/") || location.pathname.startsWith("/party/") || location.pathname.startsWith("/profile/edit");

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-neutral-950 text-white overflow-hidden relative shadow-2xl border-x border-neutral-800">
      <main className={cn("flex-1 overflow-y-auto overflow-x-hidden no-scrollbar", !shouldHideNav && "pb-20")}>
        {children}
      </main>
      {!shouldHideNav && <BottomNav />}
    </div>
  );
}

function BottomNav() {
  const location = useLocation();

  const navItems = [
    { path: "/", icon: Gamepad2, label: "Match" },
    { path: "/social", icon: Users, label: "Social" },
    { path: "/chat", icon: MessageCircle, label: "Chats" },
    { path: "/profile", icon: UserRound, label: "Perfil" },
  ];

  return (
    <nav className="absolute bottom-0 w-full bg-neutral-900 border-t border-neutral-800 px-6 py-3 flex justify-between items-center z-50">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path || (item.path !== "/" && location.pathname.startsWith(item.path));
        const Icon = item.icon;
        
        return (
          <Link 
            key={item.path} 
            to={item.path}
            className={cn(
              "flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300",
              isActive ? "text-primary text-emerald-400" : "text-neutral-500 hover:text-neutral-300"
            )}
          >
            <div className="relative">
              <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
              {isActive && (
                <motion.div
                  layoutId="bottom-nav-active"
                  className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-400 rounded-full"
                />
              )}
            </div>
            <span className="text-[10px] font-medium">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
