import React, { useState } from "react";
import { motion, useMotionValue, useTransform, AnimatePresence } from "motion/react";
import { UserSquare2, Gamepad2, X, Heart, MessageSquare } from "lucide-react";
import { MOCK_USERS, User } from "../data/mockData";
import { GAMES } from "../data/games";

export function Discovery() {
  const [cards, setCards] = useState(MOCK_USERS);
  const [history, setHistory] = useState<User[]>([]);

  const handleSwipe = (direction: "left" | "right", user: User) => {
    setCards((prev) => prev.filter((c) => c.id !== user.id));
    if (direction === "right") {
      setHistory((prev) => [...prev, user]);
      // In a real app we'd dispatch a like to the backend here
    }
  };

  return (
    <div className="h-full w-full flex flex-col relative bg-neutral-950">
      <div className="pt-8 pb-4 px-6 flex justify-between items-center z-10">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>NexusMatch</span>
            <Gamepad2 className="text-emerald-400" />
          </h1>
          <p className="text-neutral-400 text-sm">Encuentra tu duo perfecto</p>
        </div>
      </div>

      <div className="flex-1 relative flex items-center justify-center p-4">
        <AnimatePresence>
          {cards.length === 0 && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="flex flex-col items-center justify-center text-neutral-500 h-full"
            >
              <UserSquare2 size={64} className="mb-4 opacity-50" />
              <p className="text-lg">No hay más jugadores cerca de ti.</p>
              <button 
                onClick={() => setCards(MOCK_USERS)}
                className="mt-4 px-6 py-2 bg-neutral-800 rounded-full text-white hover:bg-neutral-700 transition"
              >
                Volver a buscar
              </button>
            </motion.div>
          )}

          {cards.map((user, index) => {
            const isFront = index === cards.length - 1;
            return (
              <SwipeCard 
                key={user.id} 
                user={user} 
                isFront={isFront} 
                onSwipe={(dir) => handleSwipe(dir, user)} 
              />
            );
          })}
        </AnimatePresence>
      </div>
      
      {cards.length > 0 && (
        <div className="pb-8 px-8 flex justify-center gap-6 z-10">
          <button 
            onClick={() => handleSwipe("left", cards[cards.length - 1])}
            className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center shadow-lg border border-neutral-700 text-red-400 hover:bg-neutral-700 transition"
          >
            <X size={32} />
          </button>
          <button 
            onClick={() => handleSwipe("right", cards[cards.length - 1])}
            className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)] text-white hover:bg-emerald-400 transition"
          >
            <Heart size={32} fill="currentColor" />
          </button>
        </div>
      )}
    </div>
  );
}

const SwipeCard: React.FC<{ user: User; isFront: boolean; onSwipe: (dir: "left" | "right") => void }> = ({ user, isFront, onSwipe }) => {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-15, 15]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (_e: any, info: any) => {
    if (info.offset.x > 100) {
      onSwipe("right");
    } else if (info.offset.x < -100) {
      onSwipe("left");
    } else {
      // snap back is handled by framer motion automatically with dragConstraints
    }
  };

  const userGames = GAMES.filter(g => user.games.includes(g.id));

  return (
    <motion.div
      style={{
        x: isFront ? x : 0,
        rotate: isFront ? rotate : 0,
        opacity: isFront ? 1 : 0, // Simplified: hide background cards for performance, or use scale
      }}
      drag={isFront ? "x" : false}
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      className={`absolute inset-0 m-4 rounded-[32px] overflow-hidden bg-neutral-900 border border-neutral-800 shadow-2xl origin-bottom touch-none`}
    >
      <div className="absolute inset-0">
        <img src={user.image} alt={user.name} className="w-full h-full object-cover" draggable={false} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
      </div>

      <div className="absolute bottom-0 w-full p-6 flex flex-col gap-3">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-bold text-white leading-none">
              {user.name} <span className="text-xl font-normal text-neutral-300 ml-1">{user.age}</span>
            </h2>
            <p className="text-emerald-400 font-medium mt-1">{user.playStyle}</p>
          </div>
        </div>

        <p className="text-neutral-300 text-sm line-clamp-2">{user.bio}</p>
        
        <div className="flex gap-2 text-xs text-neutral-400 items-center">
          <MessageSquare size={14} /> {user.language}
        </div>

        <div className="flex gap-2 mt-2 overflow-x-auto no-scrollbar pb-2">
          {userGames.map(g => (
            <div key={g.id} className="flex-shrink-0 w-12 h-16 rounded-lg overflow-hidden relative border border-neutral-700/50">
              <img src={g.image} alt={g.name} className="w-full h-full object-cover opacity-80" draggable={false} />
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
