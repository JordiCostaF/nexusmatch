import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Send, Users, Settings, Image as ImageIcon, Plus } from "lucide-react";
import { MOCK_MESSAGES, MOCK_USERS, MOCK_PARTIES } from "../data/mockData";
import { GAMES } from "../data/games";

export function PartyChatRoom() {
  const { id } = useParams();
  const [messages, setMessages] = useState(MOCK_MESSAGES);
  const [inputVal, setInputVal] = useState("");
  const [showMembers, setShowMembers] = useState(false);

  const currentUserId = "u1"; // Mocked
  const party = MOCK_PARTIES.find(p => p.id === id);
  const game = party ? GAMES.find(g => g.id === party.gameId) : null;

  if (!party) return <div className="p-4 text-white">Party no encontrada</div>;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    setMessages([...messages, {
      id: Date.now().toString(),
      senderId: currentUserId,
      text: inputVal,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }]);
    setInputVal("");
  };

  const partyMembers = party.members.map(memberId => MOCK_USERS.find(u => u.id === memberId)).filter(Boolean) as typeof MOCK_USERS;

  return (
    <div className="h-full w-full bg-neutral-950 flex flex-col relative z-50">
      {/* Header */}
      <div className="px-4 py-3 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/social" className="text-neutral-400 hover:text-white p-1 rounded-lg">
            <ArrowLeft size={24} />
          </Link>
          <div className="flex flex-col">
            <h2 className="font-semibold text-white leading-tight truncate max-w-[200px]">{party.name}</h2>
            <p className="text-xs text-emerald-400">{game?.name} • {partyMembers.length}/{party.maxMembers} Jugadores</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setShowMembers(!showMembers)}
            className={`p-2 rounded-lg transition ${showMembers ? 'bg-neutral-800 text-emerald-400' : 'text-neutral-400 hover:text-white'}`}
          >
            <Users size={20} />
          </button>
          <button className="text-neutral-400 hover:text-white p-2">
            <Settings size={20} />
          </button>
        </div>
      </div>

      {/* Expandable Members Header */}
      {showMembers && (
        <div className="bg-neutral-900 border-b border-neutral-800 px-4 py-3">
          <div className="flex gap-4 overflow-x-auto no-scrollbar">
            {partyMembers.map(member => (
              <div key={member.id} className="flex flex-col items-center gap-1 min-w-[60px]">
                <div className="relative">
                  <img src={member.image} alt={member.name} className="w-12 h-12 rounded-full object-cover border-2 border-neutral-700" />
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-neutral-900" />
                </div>
                <span className="text-[10px] text-white truncate max-w-[60px] text-center">{member.name}</span>
              </div>
            ))}
            {partyMembers.length < party.maxMembers && (
              <div className="flex flex-col items-center gap-1 min-w-[60px]">
                <button className="w-12 h-12 rounded-full border-2 border-dashed border-neutral-600 flex items-center justify-center text-neutral-500 hover:text-white hover:border-emerald-500 hover:bg-emerald-500/10 transition">
                  <Plus size={20} />
                </button>
                <span className="text-[10px] text-neutral-400 text-center">Invitar</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        {messages.map((msg, idx) => {
          const isMe = msg.senderId === currentUserId;
          const sender = !isMe ? MOCK_USERS.find(u => u.id === msg.senderId) : null;
          const showAvatar = !isMe && (idx === messages.length - 1 || messages[idx + 1].senderId !== msg.senderId);

          return (
            <div key={msg.id} className={`flex gap-2 max-w-[85%] ${isMe ? 'self-end' : 'self-start'}`}>
              {!isMe && (
                <div className="w-6 flex-shrink-0 flex items-end">
                  {showAvatar && sender && (
                    <img src={sender.image} className="w-6 h-6 rounded-full object-cover" alt="" />
                  )}
                </div>
              )}
              <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                {!isMe && showAvatar && sender && (
                  <span className="text-[10px] text-neutral-500 mb-1 ml-1">{sender.name}</span>
                )}
                <div className={`px-4 py-2.5 rounded-2xl text-sm ${
                  isMe 
                    ? 'bg-emerald-500 text-neutral-950 rounded-br-sm' 
                    : 'bg-neutral-800 text-white rounded-bl-sm border border-neutral-700'
                }`}>
                  {msg.text}
                </div>
                <span className="text-[10px] text-neutral-600 mt-1">{msg.timestamp}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input */}
      <div className="p-3 bg-neutral-900 border-t border-neutral-800">
        <form onSubmit={handleSend} className="flex gap-2 items-end">
          <button type="button" className="p-3 text-neutral-400 hover:text-white transition rounded-xl bg-neutral-800 border border-neutral-700 shrink-0">
            <ImageIcon size={20} />
          </button>
          
          <div className="flex-1 bg-neutral-800 border border-neutral-700 rounded-xl flex items-center overflow-hidden">
            <input 
              type="text" 
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Habla con la party..."
              className="w-full bg-transparent px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none"
            />
          </div>

          <button 
            type="submit" 
            disabled={!inputVal.trim()}
            className="p-3 bg-emerald-500 text-neutral-950 rounded-xl hover:bg-emerald-400 transition shrink-0 disabled:opacity-50 disabled:bg-neutral-800 disabled:text-neutral-500 border border-neutral-700 disabled:border-transparent"
          >
            <Send size={20} className={inputVal.trim() ? "translate-x-0.5 -translate-y-0.5" : ""} />
          </button>
        </form>
      </div>
    </div>
  );
}
