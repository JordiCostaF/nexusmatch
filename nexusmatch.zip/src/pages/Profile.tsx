import { Link } from "react-router-dom";
import { Settings, Edit2, LogOut, Video } from "lucide-react";
import { MOCK_USERS } from "../data/mockData";
import { GAMES } from "../data/games";
import { cn } from "../lib/utils";

export function Profile() {
  const currentUser = MOCK_USERS[0]; // mock current user
  
  return (
    <div className="h-full w-full bg-neutral-950 flex flex-col relative">
      <div className="absolute top-0 w-full h-48 bg-gradient-to-b from-emerald-500/20 to-transparent pointer-events-none" />
      
      <div className="pt-8 pb-4 px-6 flex justify-between items-center z-10 relative">
        <h1 className="text-2xl font-bold tracking-tight text-white">Mi Perfil</h1>
        <button className="text-neutral-400 hover:text-white transition">
          <Settings size={24} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-20 relative z-10">
        <div className="flex flex-col mb-8 mt-4">
          <div className="relative w-28 h-28 mx-auto mb-4">
            <img 
              src={currentUser.image} 
              alt={currentUser.name} 
              className="w-full h-full rounded-full object-cover border-4 border-neutral-950 shadow-xl" 
            />
            <Link to="/profile/edit" className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-emerald-500 text-neutral-950 flex items-center justify-center hover:bg-emerald-400 transition shadow-lg border-2 border-neutral-950">
              <Edit2 size={14} />
            </Link>
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-1">{currentUser.name}, {currentUser.age}</h2>
            <div className="flex items-center justify-center gap-2 mb-3">
              <span className="px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-[10px] font-medium text-emerald-400 uppercase tracking-wide">
                {currentUser.playStyle}
              </span>
            </div>
            <p className="text-neutral-400 text-sm max-w-[280px] mx-auto">
              {currentUser.bio}
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-white">Mis Juegos Favoritos</h3>
              <Link to="/profile/edit" className="text-sm text-emerald-400 font-medium">Editar</Link>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {currentUser.games.map(gameId => {
                const game = GAMES.find(g => g.id === gameId);
                return game ? (
                  <div key={game.id} className="aspect-[3/4] rounded-lg overflow-hidden relative group">
                    <img src={game.image} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition" alt={game.name} />
                  </div>
                ) : null;
              })}
              <button className="aspect-[3/4] rounded-lg border border-dashed border-neutral-700 hover:border-emerald-500/50 hover:bg-emerald-500/10 flex items-center justify-center text-neutral-500 transition">
                <Plus size={20} />
              </button>
            </div>
          </div>

          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5">
            <h3 className="font-semibold text-white mb-4">Opciones</h3>
            <div className="space-y-1">
              <OptionRow icon={Video} label="Conectar cuenta de Twitch" />
              <div className="h-px w-full bg-neutral-800 my-2" />
              <OptionRow icon={Settings} label="Preferencias de Match" />
              <div className="h-px w-full bg-neutral-800 my-2" />
              <OptionRow icon={LogOut} label="Cerrar Sesión" isDestructive />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function OptionRow({ icon: Icon, label, isDestructive = false }: { icon: any, label: string, isDestructive?: boolean }) {
  return (
    <button className={cn(
      "w-full flex items-center gap-3 p-2 rounded-lg transition",
      isDestructive ? "text-red-400 hover:bg-red-400/10" : "text-neutral-300 hover:text-white hover:bg-neutral-800"
    )}>
      <Icon size={20} />
      <span className="font-medium text-sm">{label}</span>
    </button>
  );
}

import { Plus } from "lucide-react";
