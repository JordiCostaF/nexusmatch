import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Save, Plus, X } from "lucide-react";
import { MOCK_USERS, PlayStyle } from "../data/mockData";
import { GAMES } from "../data/games";

const PLAYSTYLES: PlayStyle[] = ["Casual", "Competitivo", "Por Diversión", "Grabar Videos/Content Creator"];

export function EditProfile() {
  const navigate = useNavigate();
  const currentUser = MOCK_USERS[0];
  
  const [name, setName] = useState(currentUser.name);
  const [bio, setBio] = useState(currentUser.bio);
  const [playStyle, setPlayStyle] = useState<PlayStyle>(currentUser.playStyle);
  const [selectedGames, setSelectedGames] = useState(currentUser.games);

  const toggleGame = (id: string) => {
    if (selectedGames.includes(id)) {
      setSelectedGames(selectedGames.filter(g => g !== id));
    } else {
      setSelectedGames([...selectedGames, id]);
    }
  };

  const handleSave = () => {
    // Implement mock save logice here
    navigate(-1);
  };

  return (
    <div className="h-full w-full bg-neutral-950 flex flex-col relative z-50">
      <div className="px-4 py-4 bg-neutral-950/80 backdrop-blur-lg border-b border-neutral-800 sticky top-0 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="text-neutral-400 hover:text-white p-1">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Editar Perfil</h1>
        </div>
        <button onClick={handleSave} className="text-emerald-400 hover:text-emerald-300 font-medium px-3 py-1 flex items-center gap-2">
          <Save size={18} />
          Guardar
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-8 pb-12">
        <div className="flex flex-col items-center">
          <div className="relative w-24 h-24 mb-3">
            <img 
              src={currentUser.image} 
              className="w-full h-full rounded-xl object-cover border border-neutral-800" 
              alt="Avatar" 
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center rounded-xl opacity-0 hover:opacity-100 transition cursor-pointer">
              <span className="text-xs text-white font-medium">Cambiar</span>
            </div>
          </div>
        </div>

        <div className="space-y-5">
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Nombre</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 focus:border-emerald-500 rounded-xl px-4 py-3 text-white transition outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Biografía</label>
            <textarea 
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              className="w-full bg-neutral-900 border border-neutral-800 focus:border-emerald-500 rounded-xl px-4 py-3 text-white transition outline-none resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Estilo de Juego</label>
            <div className="flex flex-wrap gap-2">
              {PLAYSTYLES.map(style => (
                <button
                  key={style}
                  onClick={() => setPlayStyle(style)}
                  className={`px-3 py-1.5 rounded-lg border text-sm transition ${
                    playStyle === style 
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-400" 
                      : "bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-white"
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Tus Juegos</label>
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4">
              <div className="grid grid-cols-4 gap-3 mb-4">
                {selectedGames.map(gameId => {
                  const game = GAMES.find(g => g.id === gameId);
                  if (!game) return null;
                  return (
                    <div key={gameId} className="relative aspect-[3/4] rounded-lg overflow-hidden group">
                      <img src={game.image} className="w-full h-full object-cover" alt="" />
                      <button 
                        onClick={() => toggleGame(gameId)}
                        className="absolute inset-0 bg-red-500/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
                      >
                        <X size={24} className="text-white" />
                      </button>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-neutral-500 mb-3 block">Selecciona para añadir populares:</p>
              <div className="flex flex-wrap gap-2">
                {GAMES.slice(0, 8).filter(g => !selectedGames.includes(g.id)).map(g => (
                  <button
                    key={g.id}
                    onClick={() => toggleGame(g.id)}
                    className="flex items-center gap-2 pr-3 pl-1 py-1 rounded-full bg-neutral-950 border border-neutral-800 text-xs text-neutral-400 hover:text-white hover:border-emerald-500/50 transition"
                  >
                    <img src={g.image} className="w-5 h-5 rounded-full object-cover" alt="" />
                    {g.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
