import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { MOCK_USERS, MOCK_CHATS, MATCHES } from "../data/mockData";

export function Chats() {
  return (
    <div className="h-full w-full bg-neutral-950 flex flex-col">
      <div className="pt-8 pb-4 px-6 sticky top-0 bg-neutral-950/80 backdrop-blur-lg z-20">
        <h1 className="text-2xl font-bold tracking-tight text-white mb-6">Mensajes</h1>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
          <input 
            type="text" 
            placeholder="Buscar chats..." 
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:border-emerald-500/50 transition-colors"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-8">
        {/* Matches Section */}
        <div className="px-6 mb-6">
          <h2 className="text-sm font-semibold text-neutral-400 mb-3 uppercase tracking-wider">Nuevos Matches</h2>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {MATCHES.map((id) => {
              const u = MOCK_USERS.find(user => user.id === id);
              if (!u) return null;
              return (
                <Link to={`/chat/new-${u.id}`} key={u.id} className="flex flex-col items-center gap-1 min-w-[72px]">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-emerald-500 p-0.5">
                    <img src={u.image} className="w-full h-full rounded-full object-cover" alt={u.name} />
                  </div>
                  <span className="text-xs text-white truncate w-full text-center">{u.name}</span>
                </Link>
              );
            })}
          </div>
        </div>

        <div className="px-4 flex flex-col">
          <h2 className="text-sm font-semibold text-neutral-400 mb-2 px-2 uppercase tracking-wider">Mensajes</h2>
          {MOCK_CHATS.map((chat) => {
            const isGroup = chat.isGroup;
            let title = chat.name;
            let image = "";
            
            if (!isGroup) {
              const otherUserId = chat.participantIds.find(id => id !== "u1"); // Assuming u1 is current user
              const otherUser = MOCK_USERS.find(u => u.id === otherUserId);
              if (otherUser) {
                title = otherUser.name;
                image = otherUser.image;
              }
            } else {
              title = chat.name || "Party";
            }

            return (
              <Link to={isGroup && chat.partyId ? `/party/${chat.partyId}` : `/chat/${chat.id}`} key={chat.id} className="flex gap-4 p-3 hover:bg-neutral-900 rounded-2xl cursor-pointer transition items-center">
                <div className="relative flex-shrink-0">
                  {isGroup ? (
                    <div className="w-14 h-14 rounded-xl bg-neutral-800 flex items-center justify-center border border-neutral-700 text-neutral-400">
                      <span className="text-xl">🎮</span>
                    </div>
                  ) : (
                    <img src={image} alt={title} className="w-14 h-14 rounded-full object-cover bg-neutral-800" />
                  )}
                  {!isGroup && chat.unreadCount && chat.unreadCount > 0 && (
                    <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-neutral-950 rounded-full" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <h3 className="font-semibold text-white truncate">{title}</h3>
                    <span className="text-xs text-neutral-500 flex-shrink-0">
                      {chat.lastMessageTime}
                    </span>
                  </div>
                  <p className={`text-sm truncate ${chat.unreadCount ? 'text-white font-medium' : 'text-neutral-400'}`}>
                    {chat.lastMessage}
                  </p>
                </div>
                {chat.unreadCount && chat.unreadCount > 0 && (
                  <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center text-[10px] font-bold text-neutral-950">
                    {chat.unreadCount}
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
